package com.joon.mysql.test;

public class Main {
	public static void main(String[] args) {
		ProcBoard procboard = new ProcBoard();
		procboard.run();
		
}
}