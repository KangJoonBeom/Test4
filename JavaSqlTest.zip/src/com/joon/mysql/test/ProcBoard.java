package com.joon.mysql.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	Scanner sc = new Scanner(System.in);

	void run() {
		System.out.println("☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆게시판☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆");
		dbInit();
		loop_a: while (true) {
			System.out.println("[1. 리스트 2. 글 읽기 3. 글 쓰기 4. 글 삭제 5. 글 수정 e. 시스템 종료]");
			System.out.print("명령입력: ");
			String cmd = sc.next();
			switch (cmd) {
			case "1":
				System.out.println("글 리스트 입니다");
				System.out.println("글 번호 /  글 제목 / 작성자id / 작성시간");
				try {
					result = st.executeQuery("select * from board");
					while (result.next()) {
						String no = result.getString("b_no");
						String title = result.getString("b_title");
						String id = result.getString("b_id");
						String datetime = result.getString("b_datetime");
						System.out.println(no + " " + title + " " + id + " " + datetime);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "2":
				System.out.print("읽을 번호를 입력해주세요 : ");
				String readNo = sc.next();
				try {
					result = st.executeQuery("select * from board where b_no =" + readNo);
					result.next();
					String title = result.getString("b_title");
					String content = result.getString("b_text");
					System.out.println("제목: " + title);
					System.out.println("내용: " + content);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "3":
					System.out.print("제목을 입력해주세요 : ");
					String title = sc.next();
					System.out.print("내용을 입력해주세요 : ");
					String content = sc.next();
					System.out.print("id를 입력해주세요 : ");
					String id = sc.next();
					try {
						st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_text,b_hit)" + " values ('" + title + "','" + id + "',now(),'" + content + "',0)");
						System.out.println("등록 완료");
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
			case "4":
				System.out.print("삭제할 번호를 입력해주세요 : ");
				String delNo = sc.next();
				dbExecuteUpdate("delete from board where b_no=" + delNo);
				break;
			case "5":
				System.out.print("수정할 번호를 입력해주세요 : ");
				String editNo = sc.next();
				System.out.print("제목을 입력해주세요 : ");
				String edTitle = sc.next();
				System.out.print("id를 입력해주세요 : ");
				String edId = sc.next();
				System.out.print("내용을 입력해주세요 : ");
				String edContent = sc.next();
				dbExecuteUpdate("update board set b_title='" + edTitle + "',b_id='" + edId
						+ "',b_datetime=now(),b_text='" + edContent + "' where b_no=" + editNo);
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop_a;
				
			}
		}
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "0000");
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.print("처리된 횟수 " + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}